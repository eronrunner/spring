import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tag-bar',
  templateUrl: './tag-bar.component.html',
  styleUrls: ['./tag-bar.component.css']
})
export class TagBarComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
