import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-system-development',
  templateUrl: './system-development.component.html',
  styleUrls: ['./system-development.component.css']
})
export class SystemDevelopmentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
