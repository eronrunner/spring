import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-asset-status',
  templateUrl: './asset-status.component.html',
  styleUrls: ['./asset-status.component.css']
})
export class AssetStatusComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
