import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-share-trips',
  templateUrl: './share-trips.component.html',
  styleUrls: ['./share-trips.component.css']
})
export class ShareTripsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
