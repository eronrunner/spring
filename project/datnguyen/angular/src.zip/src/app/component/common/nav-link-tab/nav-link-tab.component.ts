import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nav-link-tab',
  templateUrl: './nav-link-tab.component.html',
  styleUrls: ['./nav-link-tab.component.css']
})
export class NavLinkTabComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
