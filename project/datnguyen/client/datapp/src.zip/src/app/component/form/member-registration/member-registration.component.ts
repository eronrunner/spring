import { Component, OnInit } from '@angular/core';
import {MatToolbar, MatDialog, MatButton, MatFormField, MatFormFieldControl, MatRadioButton,MatRadioGroup,
  MatList, MatListItem, MatMenu, MatMenuItem, MatInput, MatIcon, MatCardImage, MatButtonToggleModule,
  MatCardLgImage, MatCardMdImage, MatSnackBar} from '@angular/material';

@Component({
  selector: 'form-member-registration',
  templateUrl: './member-registration.component.html',
  styleUrls: ['./member-registration.component.css']
})
export class MemberRegistrationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
